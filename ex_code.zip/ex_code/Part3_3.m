clc;
clear all;

% 参数
C = 0.00545;
m = 725;
R = 4.4;
g = 9.8;
ze = 0.012;
ie = sqrt(m * g / C) * ze;
ue = ie * R;

% 状态空间矩阵
A = [0 1 0;
     2 * C * ie^2 / (m * ze^3) 0 -2 * C * ie / (m * ze^2);
     0 ie / ze -R * ze / (2 * C)];
B = [0; 0; ze / (2 * C)];
C = [1 0 0];
D = 0;

% 系统离散化（使用合理采样时间）
T = 0.0002;
sys = ss(A, B, C, D);
sys_d = c2d(sys, T, 'zoh');
A_d=sys_d.A
B_d=sys_d.B
C_d=sys_d.C
D_d=sys_d.D

%稳定性判别
root=eig(A_d);
% 计算每个元素的模
magnitudes = abs(root);
% disp(root);
if max(magnitudes)<1
    disp("离散系统稳定");
else
    disp("离散系统不稳定");
end

%能控性判别

Kc=ctrb(A_d,B_d);
if rank(Kc)==3
    disp("离散系统可控");
else
    disp("离散系统不可控");
end

%能观性判别
Ko=obsv(A_d,C_d);
if rank(Ko)==3
    disp("离散系统可观");
else
    disp("离散系统不可观");
end