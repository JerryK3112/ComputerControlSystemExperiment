clc;
clear all;

%参量
C=0.00545;
m=725;
R=4.4;
g=9.8;
ze=0.012;
ie=sqrt(m*g/C)*ze;
ue=ie*R;

%状态空间矩阵
A=[0                   1      0;
   2*C*ie^2/(m*ze^3)   0      -2*C*ie/(m*ze^2);
   0                   ie/ze  -R*ze/(2*C)]

B=[0 0 ze/(2*C)]'

C=[1 0 0]

D=0

%稳定性判别
root=eig(A);
real_part=real(root);
if max(real_part)<0
    disp("连续系统稳定");
else
    disp("连续系统不稳定");
end

%能控性判别

Kc=ctrb(A,B);
if rank(Kc)==3
    disp("连续系统可控");
else
    disp("连续系统不可控");
end

%能观性判别
Ko=obsv(A,C);
if rank(Ko)==3
    disp("连续系统可观");
else
    disp("连续系统不可观");
end