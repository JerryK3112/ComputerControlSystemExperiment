clc;
clear all;

% 参数
C = 0.00545;
m = 725;
R = 4.4;
g = 9.8;
ze = 0.012;
ie = sqrt(m * g / C) * ze;
ue = ie * R;

% 状态空间矩阵
A = [0 1 0;
     2 * C * ie^2 / (m * ze^3) 0 -2 * C * ie / (m * ze^2);
     0 ie / ze -R * ze / (2 * C)];
B = [0; 0; ze / (2 * C)];
C = [1 0 0];
D = 0;

% 系统离散化（使用合理采样时间）
T = 0.0002;
sys = ss(A, B, C, D);
sys_d = c2d(sys, T, 'zoh');
A_d=sys_d.A;
B_d=sys_d.B;
C_d=sys_d.C;
D_d=sys_d.D;

% 设计状态反馈控制器（极点配置法）
desired_poles = [0.3,0.9+j*0.1,0.9-j*0.1]; % 期望的极点位置
K = place(A_d, B_d, desired_poles);

% 初始条件
x0 = [0.02; 0;sqrt(725*9.8/0.00545)*0.02];
Time= 0.3; 
dt = round(Time / T)+1; 
state = zeros(3, dt);
state(:, 1) = x0;
input=zeros(1, dt);

% 目标状态
finish= [0.012; 0;sqrt(725*9.8/0.00545)*0.012];

% 离散状态空间方程迭代求解
for k = 1:dt - 1
    error = state(:, k) - finish;
    u=-K*error;
    input(k)=u;
    state(:, k + 1) = A_d * state(:, k) + B_d * input(k);
end

% 绘制 z 的波形变化
time = (0:dt - 1) * T;
z = state(1, :); % z 对应状态变量 x1
figure;
stairs(time, z, 'LineWidth', 2);  
xlabel('时间t(s)','FontSize',18);
ylabel('间隙z(m)','FontSize',18);
grid on;
hold on;

% 时间参数设置
t_total = 0.3;       % 总时长5秒
t_switch = 0;      % 切换时间1秒
dt = 0.0000002;       % 步长0.0002秒

% 生成时间向量
t = 0:dt:t_total;

% 生成阶跃信号：前1秒=0.02，后4秒=0.012
u = 0.02 * ones(size(t));
u(t > t_switch) = 0.012;  % 1秒后切换为0.012

% 绘制曲线
plot(t, u, 'r', 'LineWidth', 2);